(function() {
    setTimeout(function() {
        $('#ventana-modal').modal()
    }, 1000);
}());